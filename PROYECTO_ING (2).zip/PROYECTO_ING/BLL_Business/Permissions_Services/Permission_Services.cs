﻿using BE_Entities.Permissions;
using DAL_DataAccess.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_Business.Permissions_Services
{
    public class Permission_Services
    {
        private readonly Permission_Data permission_data;

        public Permission_Services()
        {
            permission_data = new Permission_Data();
        }

        #region CONSTRUCCIÓN EN MEMORIA

        public IPermission CrearPermisoSimple(string nombre, string descripcion = null)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El permiso debe tener un nombre.");

            return new SimplePermission(0, nombre, descripcion);
        }

        public IPermission CrearPermisoCompuesto(string nombre, string descripcion, params IPermission[] hijos)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El permiso debe tener un nombre.");

            var compuesto = new CompositePermission(0, nombre, descripcion);

            foreach (var hijo in hijos ?? Array.Empty<IPermission>())
            {
                compuesto.Agregar(hijo);
            }

            return compuesto;
        }

        public List<IPermission> Expandir(IPermission permiso)
        {
            return permiso.ObtenerPermisosSimples();
        }

        public bool Otorga(IPermission permiso, string nombrePermiso)
        {
            return permiso.Contiene(nombrePermiso);
        }

        #endregion

        #region PERSISTENCIA

        public int Guardar(IPermission permiso)
        {
            int resultado = permission_data.Insertar(permiso);

            if (permiso is CompositePermission compuesto)
            {
                foreach (var hijo in compuesto.Hijos.Where(h => h.Id > 0))
                {
                    permission_data.AsignarHijo(compuesto.Id, hijo.Id);
                }
            }

            return resultado;
        }

        public int Editar(IPermission permiso) => permission_data.Editar(permiso);

        public int Borrar(IPermission permiso) => permission_data.Borrar(permiso);

        public List<IPermission> ListarTodo() => permission_data.ListarTodo();

        public List<IPermission> ObtenerArbolCompleto() => permission_data.ObtenerArbolCompleto();

        public int AsignarHijo(int idPermisoCompuesto, int idPermisoHijo)
            => permission_data.AsignarHijo(idPermisoCompuesto, idPermisoHijo);

        public int QuitarHijo(int idPermisoCompuesto, int idPermisoHijo)
            => permission_data.QuitarHijo(idPermisoCompuesto, idPermisoHijo);

        #endregion
    }
}
