﻿using BE_Entities.Permissions;
using BE_Entities.Users;
using DAL_DataAccess.DataEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL_Business.Role_Services
{
    public class Role_Services
    {
        private readonly Role_Data role_data;

        public Role_Services()
        {
            role_data = new Role_Data();
        }

        #region CONSTRUCCIÓN EN MEMORIA

        public Role CrearRol(string nombre, string descripcion, params IPermission[] permisos)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El rol debe tener un nombre.");

            var rol = new Role(0, nombre, descripcion);

            foreach (var permiso in permisos ?? Array.Empty<IPermission>())
            {
                rol.AsignarPermiso(permiso);
            }

            return rol;
        }

        #endregion

        #region PERSISTENCIA - ROLES

        public int Guardar(Role rol) => role_data.Insertar(rol);

        public int Editar(Role rol) => role_data.Editar(rol);

        public int Borrar(Role rol) => role_data.Borrar(rol);

        public List<Role> ListarTodo() => role_data.ListarTodo();

        public Role ObtenerPorId(int idRol) => role_data.ObtenerPorId(idRol);

        #endregion

        #region ASIGNACIÓN DE PERMISOS A ROLES

        public int AsignarPermiso(int idRol, int idPermiso) => role_data.AsignarPermiso(idRol, idPermiso);

        public int QuitarPermiso(int idRol, int idPermiso) => role_data.QuitarPermiso(idRol, idPermiso);

        #endregion

        #region ASIGNACIÓN DE ROLES A USUARIOS

        public int AsignarRolAUsuario(int idUsuario, int idRol) => role_data.AsignarRolAUsuario(idUsuario, idRol);

        public int QuitarRolAUsuario(int idUsuario, int idRol) => role_data.QuitarRolAUsuario(idUsuario, idRol);

        public List<Role> ObtenerRolesPorUsuario(int idUsuario) => role_data.ObtenerRolesPorUsuario(idUsuario);

        #endregion

        #region VERIFICACIÓN DE PERMISOS

        /// <summary>
        /// Trae los roles del usuario desde la BD y chequea si alguno le otorga el permiso pedido.
        /// </summary>
        public bool UsuarioTienePermiso(int idUsuario, string nombrePermiso)
        {
            var roles = ObtenerRolesPorUsuario(idUsuario);
            return roles.Any(r => r.TienePermiso(nombrePermiso));
        }

        /// <summary>
        /// Igual que la anterior, pero con roles ya cargados en memoria
        /// (por ejemplo, guardados en el UserAccount tras el login).
        /// </summary>
        public bool UsuarioTienePermiso(IEnumerable<Role> rolesDelUsuario, string nombrePermiso)
        {
            if (rolesDelUsuario == null)
                return false;

            return rolesDelUsuario.Any(rol => rol.TienePermiso(nombrePermiso));
        }

        public List<IPermission> ObtenerPermisosEfectivos(IEnumerable<Role> rolesDelUsuario)
        {
            var resultado = new List<IPermission>();

            foreach (var rol in rolesDelUsuario ?? Enumerable.Empty<Role>())
            {
                resultado.AddRange(rol.ObtenerPermisosEfectivos());
            }

            return resultado
                .GroupBy(p => p.Id)
                .Select(g => g.First())
                .ToList();
        }

        #endregion
    }
}
