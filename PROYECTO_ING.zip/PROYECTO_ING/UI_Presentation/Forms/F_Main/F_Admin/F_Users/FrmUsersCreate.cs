﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI_Presentation.Forms.F_Main;
using UI_Presentation.Languages;

namespace UI_Presentation.Forms.F_Admin
{
    public partial class FrmUsersCreate : Form
    {
        public FrmUsersCreate()
        {
            InitializeComponent();
            TraductorFormulario.Registrar(this);
        }

        #region LOAD/CARGA INICIAL
        private void FrmUsersCreate_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Text = string.Empty;
            this.ControlBox = false;
            this.Dock = DockStyle.Fill;
        }
        #endregion

        #region BOTONES
        private void btnCerrarForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region FUNCIONES

        #endregion

    }
}
